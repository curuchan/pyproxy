USAGE

paki copy paste na lang sa root folder 

wag kalimutang mag adduser sa system dun kasi magbase ng user etong proxy

./SSHPlus


nano ./killstart.sh

or nano killstart.sh


edit loob paste eto

*/#!/bin/sh
 
#kill socks proxy sshplus
pkill -f proxy.py
 
 
#start service
python ./SSHPlus/proxy.py 89 - port eto pwedeng palitan


save


lagay sa crontab -e

* * * * * /bin/sh ./killstart.sh

done